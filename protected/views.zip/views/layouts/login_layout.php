<html lang="en">
    <head>

        <meta charset="utf-8">

        <?php
        
        //->prependStylesheet($this->basePath('css/bootstrap.min.css'))
        //->prependStylesheet($this->basePath('css/style.css'));
        ?>
        <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/public/design/dist/css/AdminLTE.min.css">
        <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/public/design/dist/css/skins/skin-blue.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

        <!-- Bootstrap 3.3.5 -->
        <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/public/design/bootstrap/css/bootstrap.min.css">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
        <script src="<?php echo Yii::app()->request->baseUrl; ?>/public/js/jQuery-2.1.4.min.js"></script>
        <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
        <script src="<?php echo Yii::app()->request->baseUrl; ?>/public/js/jquery-ui-timepicker-addon.js"></script>


    </head>
    <body class="hold-transition login-page">

        <?php echo $content; ?>

        <footer>
            <p>Admin: admin : admin</p>
            <p>Teacher: teacher1 : d8e54d2394</p>
            <p>Student: student2 : student2</p>
        </footer>
    </body>
</html>















