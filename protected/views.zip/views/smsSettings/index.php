<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/promotions.css" />
<!--<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700,400italic' rel='stylesheet' type='text/css'>-->
<?php
$this->breadcrumbs = array(
    'Sms Settings',
);
?>

<div style="background:#fff; min-height:800px;">  
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>

            <td valign="top">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td valign="top" width="75%">
                            <div style="padding:20px; position:relative;">

                                <div class="edit_bttns" style="width:350px; top:30px; right:-15px;">
                                    <ul>


                                    </ul>
                                </div> 
                                
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>
