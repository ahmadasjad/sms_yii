
<script>

$(document).ready(function() {
    $("#dialog").dialog();
});

</script>

<div id="dialog" title="Dialog Title">I'm in a dialog</div>

