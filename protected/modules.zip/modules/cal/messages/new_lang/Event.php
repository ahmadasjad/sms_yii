<?php
return array(
    'Title'=>'',
    'Start'=>'',
    'End'=>'',
    'All Day'=>'',
    'Editable'=>'',
);
?>
