
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="247" valign="top">
    
    <?php $this->renderPartial('//courses/left_side');?>
    
    </td>
    <td valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top" width="75%" style="padding-left:20px;">
        <h1>Leads Dashboard</h1>
        	<div class="db_graph" style="padding:0px; margin-bottom:10px;">
    
    <div class="plbx">
    <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon1.png" width="28" height="26"></li>
    <li><a>22,500</a></li>
    <li class="smalltext">steps taken</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:25%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">22% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon2.png" width="28" height="26">
    </li>
    <li><a>11</a></li>
    <li class="smalltext">floors climbed</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:45%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">48% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon3.png" width="28" height="26"></li>
    <li><a>1.06</a></li>
    <li class="smalltext">miles traveled</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:10%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">10% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    
    <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon4.png" width="28" height="26"></li>
    <li><a>1,038</a></li>
    <li class="smalltext">calories burned</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:70%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">70% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    
    <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon5.png" width="28" height="26"></li>
    <li><a>197</a></li>
    <li class="smalltext">active score</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:12%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">12% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    
      <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon1.png" width="28" height="26"></li>
    <li><a>22,500</a></li>
    <li class="smalltext">steps taken</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:25%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">22% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon2.png" width="28" height="26">
    </li>
    <li><a>11</a></li>
    <li class="smalltext">floors climbed</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:45%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">48% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    <div class="plbxcntnt">
    <div class="graphbxleft">
    <ul>
    <li><img src="images/pl_icon3.png" width="28" height="26"></li>
    <li><a>1.06</a></li>
    <li class="smalltext">miles traveled</li>
    </ul>
    </div>
    <div class="graphbxright">
    <ul>
    <li>
    <div style=" width:150px; height:7px; background:#dadada; ">
    <div style="width:10%; background:#ff682a;height:7px;"></div>
    </div>
    </li>
    <li class="txt">10% of goal of 100,000</li>
    </ul>
    </div>
    </div>
    
    <div class="plbxbotm">
    <div class="plbxbotmlink"><a href="">View all</a></div>
    </div>
    </div>
    </div>
    
    <div class="pdtab_Con" style="width:97%; padding:0px;">
                <div style="font-size:13px; padding:5px 0px"><strong>Recent Employee Admissions</strong></div>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tbody>
                    <tr class="pdtab-h">
                      <td align="center" height="18">Date</td>
                      <td align="center">Employee Name</td>
                      <td align="center">Employee No:</td>
                      <td align="center">Department</td>
                      <td align="center">Position</td>
                      
                    </tr>
                  </tbody>
                    <tbody>
                    <tr>
                    <td align="center">2012-02-13&nbsp;</td>
                    <td align="center"><a href="#">Solove Richard</a>&nbsp;</td>
                    <td align="center">2345</td>
                    <td align="center">Computer Science</td>
                    <td align="center">HOD</td>
                    
                  </tr>
                     
               </tbody>
                <tbody>
                    <tr>
                    <td align="center">2012-02-13&nbsp;</td>
                    <td align="center"><a href="#">Aravind Swami</a></td>
                    <td align="center">2345</td>
                    <td align="center">Computer Science</td>
                    <td align="center">HOD</td>
                    
                  </tr>
                     
               </tbody>
               </table>
              </div>
        </td>
        <td valign="top" width="25%"><div class="dashSide">
        	<ul>
            	<li><a href="#" class="ico1">New Admission</a></li>
                <li class="sptr"><img src="images/line_side.png" width="1" height="130" /></li>
                <li><a href="#" class="ico2">Import Students</a></li>
                <li class="sptr"><img src="images/line_side.png" width="1" height="130" /></li>
                <li><a href="#" class="ico3">Attendance</a></li>
                <li><a href="#" class="ico4">All Students</a></li>
                <li class="sptr"><img src="images/line_side.png" width="1" height="130" /></li>
                <li><a href="#" class="ico5">Guardians</a></li>
                <li class="sptr"><img src="images/line_side.png" width="1" height="130" /></li>
                <li><a href="#" class="ico6">Categories</a></li>
                 <li><a href="#" class="ico7">Settings</a></li>
            </ul>
         <div class="clear"></div>
        </div></td>
      </tr>
    </table>

    </td>
  </tr>
</table>